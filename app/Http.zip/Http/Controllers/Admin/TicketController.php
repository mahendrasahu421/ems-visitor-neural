<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProjectTicket;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    public function index(Request $request)
    {
        $status = $request->input('status');

        $tickets = ProjectTicket::with(['client', 'project'])
            ->when($status, fn ($query) => $query->where('status', $status))
            ->latest()
            ->paginate(15)
            ->withQueryString();

        return view('admin.tickets.index', [
            'title' => 'Client Project Tickets',
            'tickets' => $tickets,
            'selectedStatus' => $status,
            'counts' => [
                'Open' => ProjectTicket::where('status', 'Open')->count(),
                'In Progress' => ProjectTicket::where('status', 'In Progress')->count(),
                'Resolved' => ProjectTicket::where('status', 'Resolved')->count(),
                'Closed' => ProjectTicket::where('status', 'Closed')->count(),
            ],
        ]);
    }

    public function show(ProjectTicket $ticket)
    {
        return view('admin.tickets.show', [
            'title' => $ticket->ticket_no,
            'ticket' => $ticket->load(['client', 'project']),
        ]);
    }

    public function update(Request $request, ProjectTicket $ticket)
    {
        $validated = $request->validate([
            'status' => ['required', 'in:Open,In Progress,Resolved,Closed'],
            'admin_note' => ['nullable', 'string', 'max:5000'],
        ]);

        $ticket->update([
            'status' => $validated['status'],
            'admin_note' => $validated['admin_note'],
            'closed_at' => in_array($validated['status'], ['Resolved', 'Closed'], true) ? now() : null,
        ]);

        return redirect()
            ->route('admin.tickets.show', $ticket)
            ->with('success', 'Ticket updated successfully.');
    }
}
