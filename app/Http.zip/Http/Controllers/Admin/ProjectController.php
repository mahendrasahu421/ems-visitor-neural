<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Project;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    public function index()
    {
        return redirect()->route('invoice.projects');
    }

    public function create()
    {
        return redirect()->route('invoice.projects.create');
    }

    public function store(Request $request)
    {
        return redirect()
            ->route('invoice.projects.create')
            ->with('error', 'Project yahi se add karein.');
    }

    public function edit($id)
    {
        $project = Project::findOrFail($id);
        $data['title'] = 'Edit Project';
        $data['project'] = $project;
        return view('admin.project.edit', $data);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'client_name' => 'required|string|max:255',
            'project_category' => 'required|string|max:255',
            'project_name' => 'required|string|max:255',
            'status' => 'required|in:active,inactive',
        ]);

        $project = Project::findOrFail($id);
        $project->update($request->only('client_name', 'project_category', 'project_name', 'status'));

        return redirect()->route('projects.index')->with('success', 'Project updated successfully.');
    }

    public function list(Request $request)
    {
        $search = $request->input('search.value') ?? null;
        $limit = $request->input('length', 10);
        $start = $request->input('start', 0);

        $query = Project::query();
        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('client_name', 'like', "%{$search}%")
                    ->orWhere('project_category', 'like', "%{$search}%")
                    ->orWhere('project_name', 'like', "%{$search}%");
            });
        }

        $totalRecord = $query->count();
        $projects = $query->skip($start)->take($limit)->get();

        $rows = [];
        foreach ($projects as $index => $project) {
            $rows[] = [
                'id' => $project->id,
                'DT_RowIndex' => $start + $index + 1,
                'client_name' => $project->client_name,
                'project_category' => $project->project_category,
                'project_name' => $project->project_name,
                'status' => $project->status === 'active'
                    ? '<span class="badge bg-success">Active</span>'
                    : '<span class="badge bg-danger">Inactive</span>',
                'status_raw' => $project->status
            ];
        }

        return response()->json([
            'draw' => intval($request->input('draw')),
            'recordsTotal' => $totalRecord,
            'recordsFiltered' => $totalRecord,
            'data' => $rows
        ]);
    }

    public function destroy($id)
    {
        $project = Project::find($id);
        if (!$project) {
            return response()->json(['success' => false, 'message' => 'Project not found.']);
        }

        try {
            $project->delete();
            return response()->json(['success' => true, 'message' => 'Project deleted successfully!']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Something went wrong.']);
        }
    }

    public function updateStatus(Request $request, $id)
    {
        $project = Project::findOrFail($id);
        $status = $request->input('status');

        if (!in_array($status, ['active', 'inactive'])) {
            return response()->json(['success' => false, 'message' => 'Invalid status.']);
        }

        $project->status = $status;
        $project->save();

        return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
    }
}
