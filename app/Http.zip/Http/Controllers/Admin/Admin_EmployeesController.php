<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Country;
use App\Models\CountryState;
use App\Models\StateCity;
use App\Models\Designation;
use App\Models\Employee;
use Illuminate\Http\Request;

class Admin_EmployeesController extends Controller
{


    public function index(Request $request)
    {
        $data['title'] = 'Employee List';

        if ($request->ajax()) {
            $employees = Employee::where('status', 'Active')->get();

            $formatted = $employees->map(function ($emp) {
                return [
                    'employee_id' => $emp->employee_id,
                    'employee_name' => $emp->employee_name,
                    'employee_email' => $emp->employee_email,
                    'employee_mobile' => $emp->employee_mobile,
                    'employment_type' => $emp->employment_type,
                    'status' => $emp->status,
                    'profile_image'  => $emp->profile_image,
                ];
            });

            return response()->json(['data' => $formatted]);
        }

        return view('admin.employee.index', $data);
    }


    public function updateStatus(Request $request, $employee_id)
    {
        $employee = Employee::where('employee_id', $employee_id)->first();

        if (!$employee) {
            return response()->json([
                'success' => false,
                'message' => 'Employee not found'
            ]);
        }

        $employee->status = $request->status == 1 ? 'Active' : 'Inactive';
        $employee->save();

        return response()->json([
            'success' => true,
            'message' => 'Status updated successfully'
        ]);
    }


    public function create()
    {
        $data['title'] = 'Add Employee';
        $data['countries'] = Country::all();
        $data['designations'] = Designation::where('status', 'Active')->get();
        return view('admin.employee.create', $data);
    }

    public function store(Request $request)
    {
        $request->validate([
            'employee_name' => 'required|string|max:255',
            'employee_email' => 'required|email|unique:employees,employee_email',
            'employee_mobile' => 'required',
            'employee_password' => 'required|string|min:6',
            'employee_gender' => 'required|in:1,2,3',
            'posting_country' => 'required',
            'posting_state' => 'required',
            'posting_city' => 'required',
            'joining_date' => 'required|date',
            'employment_type' => 'required',
            'designation_id' => 'required',
            'status' => 'required',
            'profile_image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $image_name = null;
        if ($request->hasFile('profile_image')) {
            $file = $request->file('profile_image');
            $image_name = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('uploads/employees'), $image_name);
        }

        Employee::create([
            'employee_name' => $request->employee_name,
            'employee_email' => $request->employee_email,
            'employee_mobile' => $request->employee_mobile,
            'employee_password' => bcrypt($request->employee_password),
            'employee_gender' => $request->employee_gender,
            'posting_country' => $request->posting_country,
            'posting_state' => $request->posting_state,
            'posting_city' => $request->posting_city,
            'joining_date' => $request->joining_date,
            'date_of_confirmation' => $request->date_of_confirmation,
            'employment_type' => $request->employment_type,
            'designation_id' => $request->designation_id,
            'status' => $request->status,
            'profile_image' => $image_name,
        ]);

        return redirect()->route('employees.index')->with('success', 'Employee Added Successfully');
    }

    public function edit($employee_id)
    {
        $employee = Employee::where('employee_id', $employee_id)->firstOrFail();

        $data['title'] = 'Edit Employee';
        $data['employee'] = $employee;
        $data['countries'] = Country::all();
        $data['designations'] = Designation::where('status', 'Active')->get();
        $data['states'] = CountryState::where('country_id', $employee->posting_country)->get();
        $data['cities'] = StateCity::where('state_id', $employee->posting_state)->get();

        return view('admin.employee.edit', $data);
    }

    public function update(Request $request, $employee_id)
    {
        $employee = Employee::where('employee_id', $employee_id)->firstOrFail();

        $request->validate([
            'employee_name'   => 'required|string|max:255',
            'employee_email'  => 'required|email|unique:employees,employee_email,' . $employee_id . ',employee_id',
            'employee_mobile' => 'required',
            'employee_gender' => 'required',
            'joining_date'    => 'required|date',
            'employment_type' => 'required',
            'designation_id'  => 'required',
            'status'          => 'required'
        ]);

        $data = $request->all();
        if ($request->filled('employee_password')) {
            $data['employee_password'] = bcrypt($request->employee_password);
        } else {
            unset($data['employee_password']);
        }
        if ($request->hasFile('profile_image')) {
            $file = $request->file('profile_image');
            $image_name = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('uploads/employees'), $image_name);
            $data['profile_image'] = $image_name;
        } else {
            unset($data['profile_image']);
        }

        $employee->update($data);

        return redirect()->route('employees.index')->with('success', 'Employee Updated Successfully');
    }



    public function destroy($employee_id)
    {
        $employee = Employee::where('employee_id', $employee_id)->first();

        if (!$employee) {
            return response()->json([
                'success' => false,
                'message' => 'Employee not found'
            ]);
        }

        $employee->delete();

        return response()->json([
            'success' => true,
            'message' => 'Employee deleted successfully'
        ]);
    }
    public function show($employee_id)
    {
        $employee = Employee::with(['country', 'state', 'city', 'designation'])
            ->where('employee_id', $employee_id)
            ->firstOrFail();

        return response()->json([
            'employee_id' => $employee->employee_id,
            'employee_name' => $employee->employee_name,
            'employee_email' => $employee->employee_email,
            'employee_mobile' => $employee->employee_mobile,
            'employee_gender' => $employee->employee_gender,
            'joining_date' => $employee->joining_date,
            'date_of_confirmation' => $employee->date_of_confirmation,
            'employment_type' => $employee->employment_type,
            'designation_name' => $employee->designation->designation_name ?? '',
            'status' => $employee->status,
            'profile_image' => $employee->profile_image,
            'country_name' => $employee->country->country_name ?? '',
            'state_name' => $employee->state->state_name ?? '',
            'city_name' => $employee->city->city_name ?? '',
        ]);
    }



    public function getStates($country_id)
    {
        return response()->json(
            CountryState::where('country_id', $country_id)->get()
        );
    }

    public function getCities($state_id)
    {
        return response()->json(
            StateCity::where('state_id', $state_id)->get()
        );
    }
}
