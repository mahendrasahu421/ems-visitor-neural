<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;

class permissionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data['title'] = 'Permission / List';
        $data['imageUrl'] = "https://picsum.photos/200/200?random=" . rand(1, 1000);
        return view('permissions.list', $data);
    }

    public function list(Request $request)
    {
        $search = trim((string) $request->input('search.value', ''));
        $limit = (int) $request->input('length', 10);
        $start = max(0, (int) $request->input('start', 0));

        $query = Permission::orderBy('created_at');
        $totalRecords = Permission::count();

        if ($search !== '') {
            $query->where('name', 'like', "%{$search}%");
        }

        $filteredRecords = (clone $query)->count();
        $orderColumn = (int) $request->input('order.0.column', 0);
        $orderDirection = strtolower((string) $request->input('order.0.dir', 'asc')) === 'desc' ? 'desc' : 'asc';
        $orderColumns = ['id', 'name', 'created_at', null];

        if (isset($orderColumns[$orderColumn]) && $orderColumns[$orderColumn]) {
            $query->reorder()->orderBy($orderColumns[$orderColumn], $orderDirection);
        }

        if ($limit !== -1) {
            $query->skip($start)->take(max(1, $limit));
        }

        $rows = $query->get()->map(fn ($permission) => [
            'id' => $permission->id,
            'name' => e($permission->name),
            'created_at' => $permission->created_at->format('d M, Y'),
            'action' => '<a href="' . route('permissions.edit', $permission->id) . '" class="btn btn-sm btn-primary">Edit</a>
                <form action="' . route('permissions.destroy', $permission->id) . '" method="POST" style="display:inline-block;">
                    ' . csrf_field() . method_field('DELETE') . '
                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm(\'Are you sure you want to delete this permission?\')">Delete</button>
                </form>',
        ])->values();

        return response()->json([
            'draw' => (int) $request->input('draw', 0),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $filteredRecords,
            'data' => $rows,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $data['title'] = 'Permissions / Create';
        $data['imageUrl'] = "https://picsum.photos/200/200?random=" . rand(1, 1000);
       
        return view('permissions.create', $data);
    }



    public function store(Request $request)
    {
        // validate
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|unique:permissions,name',
            'guard_name' => 'nullable|string|in:web,api' // default web
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        // store permission
        Permission::create([
            'name' => $request->name,
           
        ]);

        return redirect()->route('permission.index')
            ->with('success', 'Permission created successfully!');
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
