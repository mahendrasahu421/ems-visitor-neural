<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data['title'] = 'Role / List';
        $data['imageUrl'] = "https://picsum.photos/200/200?random=" . rand(1, 1000);

        return view('role.list', $data);
    }

    public function list(Request $request)
    {
        $search = trim((string) $request->input('search.value', ''));
        $limit = (int) $request->input('length', 10);
        $start = max(0, (int) $request->input('start', 0));

        $query = Role::with('permissions')->orderBy('created_at');
        $totalRecords = Role::count();

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhereHas('permissions', function ($permissionQuery) use ($search) {
                        $permissionQuery->where('name', 'like', "%{$search}%");
                    });
            });
        }

        $filteredRecords = (clone $query)->count();
        $orderColumn = (int) $request->input('order.0.column', 0);
        $orderDirection = strtolower((string) $request->input('order.0.dir', 'asc')) === 'desc' ? 'desc' : 'asc';
        $orderColumns = ['id', 'name', null, 'created_at', null];

        if (isset($orderColumns[$orderColumn]) && $orderColumns[$orderColumn]) {
            $query->reorder()->orderBy($orderColumns[$orderColumn], $orderDirection);
        }

        if ($limit !== -1) {
            $query->skip($start)->take(max(1, $limit));
        }

        $rows = $query->get()->map(function ($role) {
            $permissions = $role->permissions->count()
                ? $role->permissions->map(fn ($permission) => '<span class="badge bg-info text-dark me-1">' . e($permission->name) . '</span>')->implode('')
                : '<span class="text-muted">No Permissions</span>';

            return [
                'id' => $role->id,
                'name' => e($role->name),
                'permissions' => $permissions,
                'created_at' => $role->created_at->format('d M, Y'),
                'action' => '<a href="' . route('roles.edit', $role->id) . '" class="btn btn-sm btn-primary">Edit</a>
                    <form action="' . route('roles.destroy', $role->id) . '" method="POST" style="display:inline-block;">
                        ' . csrf_field() . method_field('DELETE') . '
                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm(\'Are you sure you want to delete this role?\')">Delete</button>
                    </form>',
            ];
        })->values();

        return response()->json([
            'draw' => (int) $request->input('draw', 0),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $filteredRecords,
            'data' => $rows,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $data['title'] = 'Roles / Create';
        $data['imageUrl'] = "https://picsum.photos/200/200?random=" . rand(1, 1000);
        $data['permissions'] = Permission::orderBy('name', 'ASC')->get();
        return view('role.create', $data);
    }



    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|unique:roles,name',

        ]);
        if ($validator->passes()) {
            $role = Role::create(['name' => $request->name]);
            if (!empty($request->permission)) {
                foreach ($request->permission as $name) {
                    $role->givePermissionTo($name);
                }
            }
            return redirect()->route('role.index')->with('success', 'Role created successfully!');
        } else {
            return redirect()->route('role.craete')->withInput()->withErrors($validator);
        }

    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
