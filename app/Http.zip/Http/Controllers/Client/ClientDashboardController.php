<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\ProjectTicket;
use Illuminate\Support\Facades\Auth;

class ClientDashboardController extends Controller
{
    public function index()
    {
        $client = Auth::guard('client')->user();

        return view('client.dashboard', [
            'title' => 'Client Dashboard',
            'client' => $client,
            'projectCount' => $client->matchingProjects()->count(),
            'openTicketCount' => ProjectTicket::where('client_id', $client->id)
                ->whereIn('status', ['Open', 'In Progress'])
                ->count(),
            'resolvedTicketCount' => ProjectTicket::where('client_id', $client->id)
                ->whereIn('status', ['Resolved', 'Closed'])
                ->count(),
            'recentTickets' => ProjectTicket::with('project')
                ->where('client_id', $client->id)
                ->latest()
                ->take(5)
                ->get(),
        ]);
    }
}
