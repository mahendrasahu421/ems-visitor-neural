<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\ProjectTicket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class ClientTicketController extends Controller
{
    public function index()
    {
        $client = Auth::guard('client')->user();

        return view('client.tickets.index', [
            'title' => 'Project Issue Tickets',
            'tickets' => ProjectTicket::with('project')
                ->where('client_id', $client->id)
                ->latest()
                ->paginate(10),
        ]);
    }

    public function create()
    {
        $client = Auth::guard('client')->user();

        return view('client.tickets.create', [
            'title' => 'Raise Project Issue',
            'projects' => $client->matchingProjects()
                ->where('status', 'active')
                ->orderBy('project_name')
                ->get(),
        ]);
    }

    public function store(Request $request)
    {
        $client = Auth::guard('client')->user();

        $validated = $request->validate([
            'project_id' => ['nullable', 'exists:projects,id'],
            'project_name' => ['nullable', 'string', 'max:255', 'required_without:project_id'],
            'subject' => ['required', 'string', 'max:255'],
            'priority' => ['required', 'in:Low,Medium,High,Critical'],
            'description' => ['required', 'string', 'max:5000'],
            'attachment' => ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf,doc,docx,xls,xlsx,txt', 'max:4096'],
        ]);

        $project = null;
        if (!empty($validated['project_id'])) {
            $allowedProjectIds = $client->matchingProjects()->pluck('id')->all();
            if (!in_array((int) $validated['project_id'], $allowedProjectIds, true)) {
                return back()
                    ->withInput()
                    ->with('error', 'Please select one of your assigned projects.');
            }

            $project = Project::find($validated['project_id']);
        }

        $attachmentPath = null;
        if ($request->hasFile('attachment')) {
            $attachmentPath = $request->file('attachment')->store('ticket-attachments', 'public');
        }

        $ticket = ProjectTicket::create([
            'ticket_no' => $this->generateTicketNumber(),
            'client_id' => $client->id,
            'project_id' => $project?->id,
            'project_name' => $project?->project_name ?? $validated['project_name'],
            'subject' => $validated['subject'],
            'priority' => $validated['priority'],
            'description' => $validated['description'],
            'attachment_path' => $attachmentPath,
            'status' => 'Open',
        ]);

        return redirect()
            ->route('client.tickets.show', $ticket)
            ->with('success', 'Ticket raised successfully.');
    }

    public function show(ProjectTicket $ticket)
    {
        $client = Auth::guard('client')->user();

        abort_unless($ticket->client_id === $client->id, 403);

        return view('client.tickets.show', [
            'title' => $ticket->ticket_no,
            'ticket' => $ticket->load('project'),
        ]);
    }

    private function generateTicketNumber(): string
    {
        do {
            $ticketNo = 'TKT-' . now()->format('Ymd') . '-' . Str::upper(Str::random(5));
        } while (ProjectTicket::where('ticket_no', $ticketNo)->exists());

        return $ticketNo;
    }
}
